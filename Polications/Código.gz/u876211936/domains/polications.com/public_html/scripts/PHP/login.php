<?php

header("Content-Type: text/html;charset=utf-8");
    require 'conec.php';
    $acentos = $conexion->query("SET NAMES 'utf8'");

$usuario=$_POST['usuario'];
$contrasena=$_POST['password'];






$consulta="SELECT * FROM `usuarios` WHERE Usuario ='$usuario' AND Password ='$contrasena'";
$resultado=mysqli_query($conexion,$consulta);

$filas=mysqli_num_rows($resultado);

if($filas){
  
    header("location:../../index.php");
    session_start();
    $_SESSION["usuario"] = $usuario;
}else{
    
  header("location:../../login.php");
}
mysqli_free_result($resultado);
mysqli_close($conexion);
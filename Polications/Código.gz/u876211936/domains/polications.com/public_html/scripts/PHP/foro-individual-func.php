<?php

    

    $q = $_GET['q'];
    echo $q;
    /*
    $con = mysqli_connect('localhost','peter','abc123','my_db');
    if (!$con) {
      die('Could not connect: ' . mysqli_error($con));
    }

    mysqli_select_db($con,"ajax_demo");
    $sql="SELECT * FROM user WHERE id = '".$q."'";
    $result = mysqli_query($con,$sql);

    

    header("Content-Type: text/html;charset=utf-8");
        require 'conec.php';
        $acentos = $conexion->query("SET NAMES 'utf8'");


    $sql = "INSERT INTO `lorem ipsum 1`(`Usuario`, `Texto`, `Tiempo`, `Tipo`, `Tema`)
       VALUES ('$deaut','$detit','$deedi','$fecha','$ISBN','$genero','$dedes', '$nombre_archivo')";

       //ejecucuion de la sentencia
       $ejecucion=mysqli_query($conexion, $sql);
*/?>
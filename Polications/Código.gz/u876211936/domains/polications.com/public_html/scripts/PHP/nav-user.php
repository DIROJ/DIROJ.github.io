<?php
function nav(){
    require 'consulta-user.php';
    global $proofuser;
    echo '<nav>';
    echo '<div id="mySidenav" class="sidenav">';
    echo '        <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>';  /*Configuracion de Boton*/
    echo '        <a href="/"   >Inicio</a>';                                  /*Navegacion de Páginas*/
    
                if (verificar_rol($_SESSION["usuario"]) == 'Administrador'){
    echo '        <a href="/FAQ/index-admin.php"     >Preguntas Frecuentes</a>';
                    $proofuser = verificar_rol($_SESSION["usuario"]);
                }else{
    echo '        <a href="/FAQ/index.php"     >Preguntas Frecuentes</a>';    
                    $proofuser = verificar_rol($_SESSION["usuario"]);
                }
    echo '        <a href="/FOROS/"   >Foros</a>';
    echo '        <a href="/Carreras/">Carreras</a>';
    echo '        <a href="/Mapa/"    >Mapa</a>';
    echo '        <br>';
    echo '        <br>';
    echo '        <br>';
    echo '        <a href="/scripts/PHP/salir.php">Cerrar Sesión</a>';
    echo '</div>';
    echo '</nav>';
                                                                                                    /*Boton de Navegación*/
    echo '      <span onclick="openNav()" class="boton"><button class="btn" aria-label="Center Align"><i class="fa fa-bars fa-3x"></i></button></span>';

}
?>
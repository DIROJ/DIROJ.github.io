<?php
function nav(){
    echo '<nav>';
    echo '<div id="mySidenav" class="sidenav">';
    echo '        <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>';  /*Configuracion de Boton*/
    echo '        <a href="/"   >Inicio</a>';                                  /*Navegacion de Páginas*/
    echo '        <a href="/FAQ/"     >Preguntas Frecuentes</a>';
    echo '        <a href="/FOROS/"   >Foros</a>';
    echo '        <a href="/Carreras/">Carreras</a>';
    echo '        <a href="/Mapa/"    >Mapa</a>';
    echo '        <br>';
    echo '        <br>';
    echo '        <br>';
    echo '        <a href="/login.php">Inicio de Sesión</a>';
    echo '        <a href="/registro.php">Registro</a>';
    echo '</div>';
    echo '</nav>';
                                                                                                    /*Boton de Navegación*/
    echo '      <span onclick="openNav()" class="boton"><button class="btn" aria-label="Center Align"><i class="fa fa-bars fa-3x"></i></button></span>';

}
?>
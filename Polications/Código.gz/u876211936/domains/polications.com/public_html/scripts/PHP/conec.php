<?php

$co_servidor = '127.0.0.1:3306';
$co_usuario = 'u876211936_RobMackena';
$co_base = 'u876211936_Prueba';
$co_pass = 'P0Lic4T10Ns';

$conexion = mysqli_connect($co_servidor, $co_usuario, $co_pass, $co_base);


?>
function add_info() {
    $('#demo-modal').modal();
}


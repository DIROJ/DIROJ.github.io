<!DOCTYPE html>
<html lang="es-MX">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Registro de Sesión</title>
	<link rel="stylesheet" type="text/css" href="styles/proof.css">
	<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
	<link rel="shortcut icon" href="images/icono_page.png" type="image/png">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" 
    integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" 
    crossorigin="anonymous">
    <meta name="description" content="En esta página puedes realizar tu registro para el sitio
	Polications">
    <meta name="author" content="Rob Mckenna">
    
</head>
<body class= "cuerpo">
	<div class="bg"></div>
	

	<nav class="nav">
		
		<a href="#" class="link">INICIO</a>
		<a href="#" class="link">PREGUNTAS FRECUENTES</a>
		<a href="#" class="link">FOROS</a>
		<a href="#" class="link">CARRERAS</a>
		<a href="#" class="link">MAPA</a>
		
		
	</nav>
    <header class="header" id="header">
		<h1 class="titulo">Polications</h1>
	</header>

		
	<main>
		

	
	</main>
    </body>
    </html>